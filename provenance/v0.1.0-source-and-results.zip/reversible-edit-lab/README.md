# Reversible Edit Lab

ROME/MEMITの局所書き込みを、**編集 → 復元 → 次の学習**まで調べる小さな研究実装。

元の重み行列を保存しない方法について、何を補助情報として残すかを明示し、復元誤差・書き込みの強さ・反復によるずれ・次の問い合わせ先への影響を測ります。

**v0.1は合成した線形連想記憶と分類器を使います。** 事前学習済みLLMのターゲット最適化、層選択、多層MEMIT全体は実装対象に含みません。NumPyだけで全数値実験が動き、グラフ生成にだけmatplotlibを使います。

## すぐに動かす

Python 3.10以上。

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[plots]"
python run_experiments.py run --out results/my_run --plots
```

既にNumPyがある環境ならインストールせず実行できます。`--plots`を省けばmatplotlibも不要です。

```bash
python3 run_experiments.py run --out results/my_run
PYTHONPATH=src python3 -m unittest discover -s tests -v
```

短い実行：

```bash
python3 run_experiments.py run --out results/quick --seeds 7 --precisions float64 float32 --cycles 16 --active-rounds 2
```

出力先には新しいディレクトリを指定してください。既存の実験結果を上書きしません。

## 実装済みの復元方法

| 方法 | 復元に渡すもの | 用途・条件 |
| --- | --- | --- |
| Checkpoint | 編集前の行列 | 評価用の基準 |
| Delta log | 編集後の行列と低ランク差分因子 | 元の行列全体を保存しない。実数演算では差し引ける |
| Old-response log | 編集後の行列、ROME書き込み条件、編集前の局所応答 | hard ROMEの失われた応答を明示的に保存 |
| Analytic ROME | 編集後の行列と固定キー・目標・方向・alpha | `alpha < 1`。旧応答や差分因子は渡さない |
| Analytic MEMIT | 編集後の行列と固定キー群・目標群・共分散 | 単一行列の固定ターゲット更新。密な共分散の保存量も計上 |
| SVD top-1 | 編集後の行列だけ | 最上位特異成分を除去する固定ヒューリスティック |
| No rollback | 編集後の行列をそのまま使う | 仮更新の蓄積による影響を見る対照 |

小さなモデルでは解析的MEMITのメタデータがチェックポイントより大きくなる場合があります。「元の行列なし」と「保存量が小さい」は別に計測します。

## Python API

```python
import numpy as np
from reversible_edit.core import rome_edit, restore_delta, restore_rome, quantize

rng = np.random.default_rng(7)
W = quantize(rng.normal(size=(8, 16)), "float32")
k = rng.normal(size=16)
v = rng.normal(size=8)
C = np.eye(16)

edit = rome_edit(W, k, v, C, alpha=0.75, precision="float32")

# 両方とも、復元関数に元のWを渡さない。
from_factors = restore_delta(edit.updated, edit.delta, precision="float32")
from_metadata = restore_rome(edit.updated, edit.spec, precision="float32")
```

`W`の規約は`(output_dim, input_dim)`。キーは列ベクトル、バッチキーは`(input_dim, edit_count)`。各関数は入力配列を変更しません。記録内の配列は独立した読み取り専用コピーです。

演算と記録はfloat64で行い、重みを書き込むたび指定精度に丸めます。最初から低精度で保存されたモデルを再現するには、上の例のように初期重みを`quantize`してください。bfloat16は直接の最近接偶数丸めをエミュレートし、内部ではfloat32配列に格納します。GPUのbfloat16演算速度や積和誤差を再現するものではありません。

## ファイル単位で編集・復元する

完全なモデルを読み込まなくても、1枚の重み行列をNPZで渡せます。

```bash
PYTHONPATH=src python3 examples/portable_edit.py --out demo
```

任意のROME入力NPZには`weight`, `key`, `value`, `covariance`を入れます。MEMITでは`key`/`value`の代わりに`keys`/`values`を使います。

```bash
python3 run_experiments.py edit --input request.npz --output edited.npz --receipt receipt.npz --editor rome --recovery delta --alpha 0.75 --precision float32
python3 run_experiments.py undo --edited edited.npz --receipt receipt.npz --output restored.npz
```

`undo`に必要なのは編集後の行列と復元記録だけです。記録には元の重み行列を格納しません。差分方式は因子だけ、解析方式は必要な内部メタデータ、SVD方式は固定ランク等の設定だけを保存します。

復元記録は編集後の行列のSHA-256と対応付けます。別の行列や追加編集後の行列に古い記録を適用しようとすると拒否します。各出力は新規作成のみ、NPZの読み込みは`allow_pickle=False`です。

このファイルAPIは、厳密に対応する編集後行列と記録による**単発復元**です。「後の編集を残して過去の一件だけを消す」機能ではありません。`run_selective_undo`では別途、逆順に戻して後続更新を再計算する必要性を検証しています。float64も含む有限精度では、丸め残差で先行記録の厳密なハッシュと一致しなくなることがあります。ファイルAPIでの一般的な複数段の復元は未対応で、その場合は黙って続けず拒否します。

## ベンチマーク構成

1. **単発更新**：soft/hard ROMEと単一行列MEMITを書き込み、元の重み・probe予測・次の同じ更新の結果を比較。
2. **書き込み強度**：ROMEの`alpha=0, .25, .75, .95, .99, .999, 1`。MEMITは共分散の保持強度を変える。
3. **128回の編集と撤回**：各時点の生きた状態から記録を作り、誤差を元重みでこっそり修正せずに累積させる。
4. **能動的問い合わせ**：3クラスの合成環境で、8候補×3仮ラベルを試して戻す。候補採点には本物のラベルを使わず、選択後にだけ教師へ問い合わせる。
5. **問い合わせ対照**：同じラベル予算でrandomとuncertaintyを比較。仮更新の計算量は一致させていない。
6. **評価順序の反転**：同じ候補を逆順に試したとき、復元誤差によって選択が変わるか測る。
7. **選択的撤回**：Aの後にBを学んだ状態からAの差分だけを引く場合と、B→Aを戻してBを再計算する場合を比較。

取得方針は未ラベルprobeの期待エントロピー減少です。自信の増加が正確さの改善につながるかを実測します。優位性を保証する目的関数として扱いません。

## 同梱した実測

[結果レポート](results/20261110/RESULTS.md)に、3seeds × 4保存精度の生データと集計を同梱しています。

- 単発比較732件、反復の観測点288件、能動学習の設定12組。
- `alpha=.95`の128回撤回では、float32の相対重み誤差は差分方式約`3.04e-7`、解析方式約`1.87e-6`。
- bfloat16では差分方式約`0.0206`、解析方式約`0.125`。この精度では単純に式を逆転するだけでは長期反復の精度を保てない。
- float32の先読みでは、差分方式・解析方式ともチェックポイント方式と問い合わせ先の全系列が3/3seedsで一致。
- 最終分類精度の平均は、先読み方式69.79%、uncertainty方式70.31%。このtoyで先読みの優位性は示していない。

誤差は重み全体の相対Frobeniusノルムです。「何%の重みを復元したか」ではありません。数値は小さな合成条件での観測で、LLMの品質やTTT性能へ直接外挿しません。

## 計測上の約束

- 元行列は評価側と明示的なチェックポイント基準が保持。復元関数は各方式で宣言した情報しか受け取らない。
- 目標値や旧応答を編集前状態から作る方法は、その情報をメタデータとして明記する。
- 因子・目標・共分散はfloat64。`kernel.csv`にはその保存量を含める。
- 評価器は比較のための行列コピーを保持する。保存ペイロードの比較からプロセスのピークメモリ削減を主張しない。
- SVDランクは最初から1。元重みを見て最適なランクを選ばない。
- テスト用の教師ラベルは取得方針に使わない。
- ソースハッシュ・実行条件・Python/NumPy版を`results.json`に保存する。

## ファイル構成

| ファイル | 内容 |
| --- | --- |
| `src/reversible_edit/core.py` | 更新・復元の数値カーネル、低精度丸め |
| `src/reversible_edit/active.py` | 仮更新と撤回を用いた問い合わせ実験 |
| `src/reversible_edit/experiments.py` | 強度・精度・反復・次更新・選択的撤回の比較 |
| `src/reversible_edit/receipts.py` | NPZ編集記録の保存・対応確認・復元 |
| `src/reversible_edit/cli.py` | 実験・編集・復元コマンド |
| `tests/` | 数学的性質、丸め、取得情報、保存復元の検証 |
| `docs/METHODS.md` | 数式、既知情報、適用範囲 |
| `docs/REAL_MODEL.md` | 実LLMの重みへ接続する際の境界 |
| `references.bib` | 原論文と後続研究 |

## 次に確かめる問い

最も具体的に残ったのは、**低精度の重みに何を最小限添えれば、繰り返しの撤回と次の学習を保てるか**です。丸め残差の保存量と復元精度、未編集部分からの旧応答の推定、実LLMでのキー・目標・層間依存の再構成を、それぞれ独立した比較として追加できます。

ライセンスはこの配布物ではまだ指定していません。外部公開時に明示してください。

