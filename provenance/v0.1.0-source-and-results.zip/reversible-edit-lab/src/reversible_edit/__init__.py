"""Reversible fixed-target write kernels and transparent toy experiments.

This package does not claim to implement the target optimization or layer
selection of full ROME/MEMIT editors. See docs/METHODS.md for access contracts.
"""

__version__ = "0.1.0"

