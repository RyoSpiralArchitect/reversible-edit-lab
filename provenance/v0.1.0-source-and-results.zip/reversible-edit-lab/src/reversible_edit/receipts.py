"""Portable NPZ receipts with explicit recovery information and tensor binding.

NPZ loading never enables pickle. No receipt contains a full original weight
matrix. The analytic and old-response modes contain the metadata they require;
they must not be described as weights-only restoration.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any
import numpy as np

from .core import (LowRankDelta, MemitSpec, RomeSpec, bottom_rank_restore,
                   memit_edit, restore_delta, restore_memit, restore_rome,
                   restore_rome_old_value, rome_edit)


def tensor_digest(weight: np.ndarray) -> str:
    w = np.ascontiguousarray(weight)
    header = json.dumps({"shape": list(w.shape), "dtype": w.dtype.str}, sort_keys=True).encode()
    return hashlib.sha256(header + w.tobytes()).hexdigest()


def _save_new_npz(path: str | Path, arrays: dict[str, Any]) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation avoids silently replacing user data.
    with destination.open("xb") as stream:
        try:
            np.savez_compressed(stream, **arrays)
        except BaseException:
            stream.close()
            destination.unlink(missing_ok=True)
            raise


def edit_npz(input_path: str | Path, output_path: str | Path, receipt_path: str | Path,
             *, editor: str = "rome", recovery: str = "delta", alpha: float = 0.75,
             precision: str = "float32", drop_rank: int = 1) -> dict:
    """Input archive: weight, covariance, and key/value or keys/values.

Input weight is treated as the current state as supplied; output writes are
rounded to precision. To emulate an initially low-precision model, quantize it
before creating the input archive. Recovery refuses to overwrite any file.
    """
    if editor not in ("rome", "memit"):
        raise ValueError("editor must be rome or memit")
    if recovery not in ("delta", "analytic", "old_response", "svd"):
        raise ValueError("Unsupported recovery strategy")
    if recovery == "old_response" and editor != "rome":
        raise ValueError("old_response receipts are for ROME")
    if recovery == "analytic" and editor == "rome" and alpha == 1:
        raise ValueError("Hard ROME is noninjective; use delta or old_response")
    if Path(output_path).exists() or Path(receipt_path).exists():
        raise FileExistsError("Output and receipt paths must be new")
    if Path(output_path).resolve() == Path(receipt_path).resolve():
        raise ValueError("Weight and receipt output paths must be distinct")
    with np.load(input_path, allow_pickle=False) as archive:
        w, c = np.array(archive["weight"]), np.array(archive["covariance"])
        if editor == "rome":
            result = rome_edit(w, archive["key"], archive["value"], c,
                               alpha=alpha, precision=precision)
        else:
            result = memit_edit(w, archive["keys"], archive["values"], c, precision=precision)
    spec = result.spec
    payload = {}
    if recovery == "delta":
        payload = {"left": result.delta.left, "right": result.delta.right}
    elif recovery in ("analytic", "old_response") and editor == "rome":
        payload = {"key": spec.key, "value": spec.value, "direction": spec.direction}
        if recovery == "old_response":
            payload["old_response"] = np.asarray(w, dtype=np.float64) @ spec.key
    elif recovery == "analytic":
        payload = {"keys": spec.keys, "values": spec.values, "covariance": spec.covariance}
    elif recovery == "svd":
        # Validate the fixed policy before publishing either output.
        if isinstance(drop_rank, bool) or not isinstance(drop_rank, int) or not 0 <= drop_rank <= min(w.shape):
            raise ValueError("drop_rank must be an integer in [0, min(weight.shape)]")
    meta = {
        "schema_version": 1, "editor": editor, "recovery": recovery,
        "precision": precision, "alpha": float(alpha) if editor == "rome" else None,
        "drop_rank": drop_rank if recovery == "svd" else None,
        "edited_tensor_sha256": tensor_digest(result.updated),
        "numeric_payload_bytes": int(sum(a.nbytes for a in payload.values())),
        "contains_original_weight": False,
        "scope": "Single fixed-target linear write; not complete ROME/MEMIT target optimization.",
    }
    _save_new_npz(output_path, {"weight": result.updated})
    try:
        _save_new_npz(receipt_path, {"__meta__": np.array(json.dumps(meta)), **payload})
    except BaseException:
        Path(output_path).unlink(missing_ok=True)
        raise
    return meta


def undo_npz(edited_path: str | Path, receipt_path: str | Path, output_path: str | Path) -> dict:
    """Restore using only a paired edited tensor and its declared receipt.

    The tensor digest rejects a stale receipt applied after subsequent edits.
    This API is a single-step paired-tensor operation. Approximate rollback may
    not recover the exact digest needed by an earlier receipt, even in float64;
    generic multi-step receipt traversal is therefore not supported.
    """
    if Path(output_path).exists():
        raise FileExistsError("Restored output path must be new")
    with np.load(edited_path, allow_pickle=False) as archive:
        edited = np.array(archive["weight"])
    with np.load(receipt_path, allow_pickle=False) as archive:
        meta = json.loads(str(archive["__meta__"].item()))
        if meta.get("schema_version") != 1:
            raise ValueError("Unsupported receipt schema")
        if tensor_digest(edited) != meta.get("edited_tensor_sha256"):
            raise ValueError("Receipt does not match this edited tensor (stale or wrong input)")
        mode, editor, precision = meta["recovery"], meta["editor"], meta["precision"]
        if editor not in ("rome", "memit") or mode not in ("delta", "analytic", "old_response", "svd"):
            raise ValueError("Unsupported receipt editor/recovery combination")
        if mode == "old_response" and editor != "rome":
            raise ValueError("old_response receipts require editor=rome")
        if mode == "delta":
            restored = restore_delta(edited, LowRankDelta(archive["left"], archive["right"]), precision=precision)
        elif mode in ("analytic", "old_response") and editor == "rome":
            spec = RomeSpec(archive["key"], archive["value"], archive["direction"], meta["alpha"])
            if mode == "analytic":
                restored = restore_rome(edited, spec, precision=precision)
            else:
                restored = restore_rome_old_value(edited, spec, archive["old_response"], precision=precision)
        elif mode == "analytic" and editor == "memit":
            spec = MemitSpec(archive["keys"], archive["values"], archive["covariance"])
            restored = restore_memit(edited, spec, precision=precision)
        elif mode == "svd":
            restored = bottom_rank_restore(edited, meta["drop_rank"], precision=precision)
        else:
            raise ValueError("Unsupported receipt editor/recovery combination")
    _save_new_npz(output_path, {"weight": restored})
    return {"recovery": mode, "output": str(output_path), "precision": precision,
            "restored_tensor_sha256": tensor_digest(restored)}

