from pathlib import Path
from tempfile import TemporaryDirectory
import json
import unittest
import numpy as np

from reversible_edit.core import quantize
from reversible_edit.receipts import edit_npz, undo_npz
from reversible_edit.experiments import ExperimentConfig, run_selective_undo


class ReceiptTests(unittest.TestCase):
    def test_portable_rome_receipts_have_only_declared_information(self):
        rng = np.random.default_rng(44)
        w, k, v = rng.normal(size=(4, 7)), rng.normal(size=7), rng.normal(size=4)
        for recovery in ("delta", "analytic", "old_response"):
            with self.subTest(recovery=recovery), TemporaryDirectory() as temp:
                base = Path(temp)
                np.savez(base/"request.npz", weight=w, covariance=np.eye(7), key=k, value=v)
                meta = edit_npz(base/"request.npz", base/"edited.npz", base/"receipt.npz",
                                recovery=recovery, alpha=0.75, precision="float64")
                # Remove the source before restoration: no original dependency.
                (base/"request.npz").unlink()
                with np.load(base/"receipt.npz", allow_pickle=False) as record:
                    self.assertNotIn("weight", record.files)
                    self.assertEqual(meta["numeric_payload_bytes"], sum(record[key].nbytes for key in record.files if key != "__meta__"))
                    if recovery == "delta":
                        self.assertEqual(set(record.files), {"__meta__", "left", "right"})
                undo_npz(base/"edited.npz", base/"receipt.npz", base/"restored.npz")
                with np.load(base/"restored.npz") as restored:
                    np.testing.assert_allclose(restored["weight"], w, rtol=2e-13, atol=2e-13)

    def test_memit_portable_inverse_counts_covariance(self):
        rng = np.random.default_rng(12)
        w, keys, values = rng.normal(size=(3, 6)), rng.normal(size=(6, 2)), rng.normal(size=(3, 2))
        with TemporaryDirectory() as temp:
            p=Path(temp)
            np.savez(p/"request.npz", weight=w, keys=keys, values=values, covariance=np.eye(6))
            meta=edit_npz(p/"request.npz", p/"edited.npz", p/"receipt.npz", editor="memit", recovery="analytic", precision="float64")
            self.assertEqual(meta["numeric_payload_bytes"], (12+6+36)*8)
            (p/"request.npz").unlink()
            undo_npz(p/"edited.npz",p/"receipt.npz",p/"restored.npz")
            with np.load(p/"restored.npz") as archive:
                np.testing.assert_allclose(archive["weight"], w, rtol=2e-13, atol=2e-13)

    def test_wrong_or_stale_tensor_is_rejected(self):
        with TemporaryDirectory() as temp:
            p=Path(temp)
            np.savez(p/"request.npz", weight=np.eye(3), covariance=np.eye(3), key=np.ones(3), value=np.zeros(3))
            edit_npz(p/"request.npz",p/"edited.npz",p/"receipt.npz")
            np.savez(p/"wrong.npz",weight=np.eye(3))
            with self.assertRaisesRegex(ValueError,"does not match"):
                undo_npz(p/"wrong.npz",p/"receipt.npz",p/"out.npz")
            self.assertFalse((p/"out.npz").exists())

    def test_hard_rome_analytic_rejection_creates_no_outputs(self):
        with TemporaryDirectory() as temp:
            p=Path(temp)
            np.savez(p/"request.npz", weight=np.eye(2), covariance=np.eye(2), key=np.ones(2), value=np.zeros(2))
            with self.assertRaisesRegex(ValueError,"noninjective"):
                edit_npz(p/"request.npz",p/"edit.npz",p/"receipt.npz",alpha=1,recovery="analytic")
            self.assertFalse((p/"edit.npz").exists())
            self.assertFalse((p/"receipt.npz").exists())

    def test_unknown_editor_is_rejected_even_for_delta_receipt(self):
        with TemporaryDirectory() as temp:
            p=Path(temp)
            np.savez(p/"request.npz",weight=np.eye(3),covariance=np.eye(3),key=np.ones(3),value=np.zeros(3))
            edit_npz(p/"request.npz",p/"edited.npz",p/"receipt.npz")
            with np.load(p/"receipt.npz") as record:
                fields={key:np.array(record[key]) for key in record.files}
            meta=json.loads(str(fields["__meta__"].item()))
            meta["editor"]="unknown"
            fields["__meta__"]=np.array(json.dumps(meta))
            np.savez(p/"bad-receipt.npz",**fields)
            with self.assertRaisesRegex(ValueError,"Unsupported"):
                undo_npz(p/"edited.npz",p/"bad-receipt.npz",p/"out.npz")
            self.assertFalse((p/"out.npz").exists())

    def test_existing_output_is_preserved(self):
        with TemporaryDirectory() as temp:
            p=Path(temp)
            (p/"edit.npz").write_bytes(b"preserve this")
            with self.assertRaises(FileExistsError):
                edit_npz(p/"missing.npz",p/"edit.npz",p/"receipt.npz")
            self.assertEqual((p/"edit.npz").read_bytes(),b"preserve this")

    def test_svd_receipt_is_weights_only(self):
        with TemporaryDirectory() as temp:
            p=Path(temp)
            np.savez(p/"request.npz",weight=np.eye(3),covariance=np.eye(3),key=np.ones(3),value=np.zeros(3))
            meta=edit_npz(p/"request.npz",p/"edited.npz",p/"receipt.npz",recovery="svd")
            self.assertEqual(meta["numeric_payload_bytes"],0)
            with np.load(p/"receipt.npz") as record:
                self.assertEqual(record.files,["__meta__"])
            undo_npz(p/"edited.npz",p/"receipt.npz",p/"restored.npz")

    def test_selective_undo_requires_replay(self):
        result=run_selective_undo()
        self.assertEqual(result["scalar"]["subtract_a_only"],1.0)
        self.assertEqual(result["scalar"]["b_without_a"],2.0)
        self.assertEqual(result["scalar"]["undo_b_a_then_replay_b"],2.0)
        self.assertGreater(result["matrix"]["naive"]["weight_relative_error"],0.01)
        self.assertLess(result["matrix"]["replayed"]["weight_relative_error"],1e-12)

    def test_invalid_run_configuration_is_rejected(self):
        for options in ({"seeds":()}, {"precisions":()}, {"cycle_count":0}, {"input_dim":1}):
            with self.subTest(options=options), self.assertRaises(ValueError):
                ExperimentConfig(**options)


if __name__ == "__main__":
    unittest.main()
