"""Behavioral checks for the synthetic acquisition experiment."""

import json
import unittest
from unittest.mock import patch

import numpy as np

from reversible_edit.active import PROTOCOLS, evaluate_acquisition_candidates, run_active_experiment


class ActiveExperimentTests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(23)
        self.weights = rng.normal(size=(3, 6))
        self.candidates = rng.normal(size=(5, 6))
        self.candidates /= np.linalg.norm(self.candidates, axis=1, keepdims=True)
        self.probes = rng.normal(size=(12, 6))
        self.covariance = np.eye(6)

    def audit(self, protocol, order="forward"):
        return evaluate_acquisition_candidates(
            self.weights, self.candidates, self.probes, self.covariance,
            protocol=protocol, order=order, precision="float64",
        )

    def test_exact_restorers_preserve_reference_query_ranking(self):
        checkpoint = self.audit("checkpoint")
        for protocol in ("factor", "analytic"):
            for order in ("forward", "reverse"):
                with self.subTest(protocol=protocol, order=order):
                    actual = self.audit(protocol, order)
                    self.assertEqual(actual.ranking, checkpoint.ranking)
                    np.testing.assert_allclose(actual.scores, checkpoint.scores, rtol=1e-11, atol=1e-12)
                    np.testing.assert_allclose(actual.final_weights, self.weights, rtol=1e-11, atol=1e-12)

    def test_acquisition_never_queries_external_teacher(self):
        with patch("reversible_edit.active._ExternalLabelOracle.query", side_effect=AssertionError("teacher leaked")):
            for protocol in PROTOCOLS:
                with self.subTest(protocol=protocol):
                    result = self.audit(protocol)
                    self.assertEqual(result.diagnostics["teacher_queries_for_acquisition"], 0)
                    self.assertFalse(result.diagnostics["heldout_labels_used_for_acquisition"])

    def test_acquisition_does_not_mutate_caller_arrays(self):
        originals = [array.copy() for array in (self.weights, self.candidates, self.probes, self.covariance)]
        for protocol in PROTOCOLS:
            self.audit(protocol)
        for actual, expected in zip((self.weights, self.candidates, self.probes, self.covariance), originals):
            np.testing.assert_array_equal(actual, expected)

    def test_full_experiment_is_deterministic_and_json_serializable(self):
        options = dict(seed=7, precision="float64", n_rounds=2, n_candidates=4, n_probes=8, n_test=24)
        first = run_active_experiment(**options)
        second = run_active_experiment(**options)
        self.assertEqual(first, second)
        json.dumps(first, allow_nan=False)
        self.assertEqual(first["total_teacher_label_queries"], 2 * (len(PROTOCOLS) * 2 + 2))
        for path in first["active_paths"]:
            self.assertEqual(path["teacher_label_queries"], 2)
            self.assertEqual(path["teacher_queries_for_acquisition"], 0)
            self.assertEqual(len(set(path["selected_pool_ids"])), 2)
        self.assertEqual({path["query_policy"] for path in first["query_baselines"]}, {"random", "uncertainty"})
        for path in first["query_baselines"]:
            self.assertEqual(path["teacher_label_queries"], 2)
            self.assertEqual(path["hypothetical_edits"], 0)
            self.assertEqual(path["restore_calls"], 0)

    def test_contamination_controls_expose_drift_without_hidden_reset(self):
        for protocol in ("bottom_rank", "no_rollback"):
            with self.subTest(protocol=protocol):
                result = self.audit(protocol)
                self.assertGreater(result.diagnostics["final_relative_weight_drift"], 1e-3)
                self.assertFalse(np.allclose(result.final_weights, self.weights))


if __name__ == "__main__":
    unittest.main()
